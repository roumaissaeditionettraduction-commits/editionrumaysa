import {
  db,
  collection,
  doc,
  onSnapshot,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  type Unsubscribe,
  type DocumentData
} from './firebase';
import { Book, Order } from '../types';

export interface FirebaseSyncLog {
  id: string;
  timestamp: string;
  action: 'listen_books' | 'push_book' | 'pull_books' | 'delete_book' | 'push_order' | 'test_connection' | 'error';
  status: 'success' | 'failed' | 'pending';
  details: string;
  count?: number;
}

const FIREBASE_LOGS_KEY = 'roumaissa_firebase_logs_v1';

export const FirebaseService = {
  // Logs management
  getLogs: (): FirebaseSyncLog[] => {
    try {
      const raw = localStorage.getItem(FIREBASE_LOGS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  },

  addLog: (
    action: FirebaseSyncLog['action'],
    status: FirebaseSyncLog['status'],
    details: string,
    count?: number
  ): void => {
    try {
      const current = FirebaseService.getLogs();
      const newLog: FirebaseSyncLog = {
        id: `flog-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        timestamp: new Date().toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        action,
        status,
        details,
        count
      };
      const updated = [newLog, ...current.slice(0, 49)];
      localStorage.setItem(FIREBASE_LOGS_KEY, JSON.stringify(updated));
      window.dispatchEvent(new Event('roumaissa-firebase-logs-updated'));
    } catch (e) {
      console.error('Failed to save Firebase log', e);
    }
  },

  // Parse Firestore document into a type-safe Book object with full fallbacks
  parseBookDoc: (id: string, data: DocumentData): Book => {
    const pricePrint = Number(data.pricePrint ?? data.price ?? data.prix ?? 1200);
    const priceEpub = Number(data.priceEpub ?? (data.hasEpub ? Math.round(pricePrint * 0.6) : 0));
    const stock = Number(data.stock ?? data.stockCount ?? data.quantity ?? 10);

    return {
      id: id || data.id || `book-${Date.now()}`,
      title: String(data.title || data.name || 'كتاب بدون عنوان'),
      originalTitle: data.originalTitle ? String(data.originalTitle) : undefined,
      author: String(data.author || 'دار رميسة للنشر'),
      translator: data.translator ? String(data.translator) : undefined,
      category: String(data.category || data.genre || 'أدب وروايات'),
      pricePrint: isNaN(pricePrint) ? 1200 : pricePrint,
      priceEpub: isNaN(priceEpub) ? 600 : priceEpub,
      hasEpub: Boolean(data.hasEpub ?? false),
      epubFileName: data.epubFileName ? String(data.epubFileName) : undefined,
      epubFileSize: data.epubFileSize ? String(data.epubFileSize) : undefined,
      coverColor: String(data.coverColor || '#1c1917'),
      coverImage: data.coverImage || data.image || data.cover || undefined,
      coverPattern: data.coverPattern || 'classic',
      coverAccent: String(data.coverAccent || '#d97706'),
      isbn: String(data.isbn || '978-9931-00-000-0'),
      pages: Number(data.pages || 250),
      publishYear: Number(data.publishYear || data.year || new Date().getFullYear()),
      publisher: String(data.publisher || 'دار رميسة للنشر والترجمة والتوزيع'),
      editionNumber: String(data.editionNumber || 'الطبعة الأولى'),
      rating: Number(data.rating || 4.8),
      reviewsCount: Number(data.reviewsCount || 12),
      summary: String(data.summary || data.description || 'نبذة عن إصدار دار رميسة المميز.'),
      excerpt: String(data.excerpt || 'مقتطف من العمل الأدبي...'),
      toc: Array.isArray(data.toc) ? data.toc : ['المقدمة', 'الفصل الأول', 'الفصل الثاني', 'الخاتمة'],
      stock: isNaN(stock) ? 10 : stock,
      isBestseller: Boolean(data.isBestSeller ?? data.isBestseller ?? false),
      isBestSeller: Boolean(data.isBestSeller ?? data.isBestseller ?? false),
      isNewRelease: Boolean(data.isNewRelease),
      isFeatured: Boolean(data.isFeatured),
      tags: Array.isArray(data.tags) ? data.tags : ['دار رميسة', 'كتب جزائرية'],
      lastSyncedAt: new Date().toISOString()
    };
  },

  // Real-time synchronization listener for "books" collection via onSnapshot
  subscribeToBooks: (
    onUpdate: (books: Book[]) => void,
    onError?: (error: Error) => void
  ): Unsubscribe => {
    try {
      const booksCollection = collection(db, 'books');
      
      const unsubscribe = onSnapshot(
        booksCollection,
        (snapshot) => {
          if (snapshot.empty) {
            FirebaseService.addLog(
              'listen_books',
              'pending',
              'مجموعة "books" في Firestore فارغة حالياً - المتجر يعمل بالبيانات المحلية'
            );
            return;
          }

          const books: Book[] = [];
          snapshot.forEach((docSnap) => {
            try {
              const book = FirebaseService.parseBookDoc(docSnap.id, docSnap.data());
              books.push(book);
            } catch (err) {
              console.warn(`Failed to parse book doc ${docSnap.id}:`, err);
            }
          });

          if (books.length > 0) {
            onUpdate(books);
            FirebaseService.addLog(
              'listen_books',
              'success',
              `تم تحديث ${books.length} كتاب لحظياً ومباشرة من Google Cloud Firestore`,
              books.length
            );
          }
        },
        (error) => {
          console.warn('Firestore onSnapshot books warning:', error);
          FirebaseService.addLog(
            'listen_books',
            'failed',
            `تنبيه Firestore: ${error.message || 'تعذر القراءة الفورية'}`
          );
          if (onError) onError(error);
        }
      );

      return unsubscribe;
    } catch (e: any) {
      console.warn('Failed to attach Firestore snapshot listener:', e);
      if (onError) onError(e);
      return () => {};
    }
  },

  // Manual Fetch all books from Firestore
  fetchAllBooks: async (): Promise<{ success: boolean; books: Book[]; message: string }> => {
    try {
      const booksCollection = collection(db, 'books');
      const snapshot = await getDocs(booksCollection);
      
      if (snapshot.empty) {
        return {
          success: true,
          books: [],
          message: 'مجموعة books في Firestore فارغة.'
        };
      }

      const books: Book[] = [];
      snapshot.forEach((docSnap) => {
        try {
          books.push(FirebaseService.parseBookDoc(docSnap.id, docSnap.data()));
        } catch (err) {
          console.warn(`Failed to parse book ${docSnap.id}`, err);
        }
      });

      FirebaseService.addLog(
        'pull_books',
        'success',
        `تم جلب ${books.length} كتاب من Firestore بنجاح`,
        books.length
      );

      return {
        success: true,
        books,
        message: `تم جلب ${books.length} كتاب بنجاح`
      };
    } catch (err: any) {
      const msg = err?.message || 'خطأ أثناء الاتصال بقاعدة بيانات Firestore';
      FirebaseService.addLog('pull_books', 'failed', msg);
      return { success: false, books: [], message: msg };
    }
  },

  // Push single book to Firestore "books" collection
  pushBook: async (book: Book): Promise<{ success: boolean; message: string }> => {
    try {
      const docId = book.id.replace(/[^a-zA-Z0-9_-]/g, '_');
      const bookRef = doc(db, 'books', docId);

      // Clean payload for Firestore
      const payload: Record<string, any> = {
        id: book.id,
        title: book.title,
        originalTitle: book.originalTitle || null,
        author: book.author,
        translator: book.translator || null,
        category: book.category,
        pricePrint: book.pricePrint,
        priceEpub: book.priceEpub,
        hasEpub: book.hasEpub,
        epubFileName: book.epubFileName || null,
        epubFileSize: book.epubFileSize || null,
        coverColor: book.coverColor,
        coverImage: book.coverImage || null,
        coverPattern: book.coverPattern || 'classic',
        coverAccent: book.coverAccent,
        isbn: book.isbn,
        pages: book.pages,
        publishYear: book.publishYear,
        publisher: book.publisher,
        editionNumber: book.editionNumber,
        rating: book.rating,
        reviewsCount: book.reviewsCount,
        summary: book.summary,
        excerpt: book.excerpt,
        toc: book.toc,
        stock: book.stock,
        stockCount: book.stockCount ?? book.stock,
        isBestseller: Boolean(book.isBestSeller ?? book.isBestseller ?? false),
        isBestSeller: Boolean(book.isBestSeller ?? book.isBestseller ?? false),
        isNewRelease: Boolean(book.isNewRelease),
        isFeatured: Boolean(book.isFeatured),
        tags: book.tags,
        updatedAt: new Date().toISOString()
      };

      await setDoc(bookRef, payload, { merge: true });

      FirebaseService.addLog(
        'push_book',
        'success',
        `تم حفظ ومزامنة الكتاب "${book.title}" في مجموعة books بنجاح`
      );

      return { success: true, message: `تم حفظ "${book.title}" في Firestore بنجاح` };
    } catch (err: any) {
      const msg = err?.message || 'تعذر حفظ الكتاب في Firestore';
      FirebaseService.addLog('push_book', 'failed', `${msg} (${book.title})`);
      return { success: false, message: msg };
    }
  },

  // Batch Push all books to Firestore
  batchPushBooks: async (books: Book[]): Promise<{ success: boolean; pushedCount: number; message: string }> => {
    try {
      let count = 0;
      for (const book of books) {
        const res = await FirebaseService.pushBook(book);
        if (res.success) count++;
      }
      return {
        success: true,
        pushedCount: count,
        message: `تم رفع ومزامنة ${count} كتاب إلى Google Firestore بنجاح`
      };
    } catch (err: any) {
      return {
        success: false,
        pushedCount: 0,
        message: err?.message || 'خطأ أثناء رفع حزمة الكتب'
      };
    }
  },

  // Delete book from Firestore
  deleteBook: async (bookId: string): Promise<{ success: boolean; message: string }> => {
    try {
      const docId = bookId.replace(/[^a-zA-Z0-9_-]/g, '_');
      await deleteDoc(doc(db, 'books', docId));

      FirebaseService.addLog(
        'delete_book',
        'success',
        `تم حذف المعرف ${bookId} من مجموعة books في Firestore`
      );
      return { success: true, message: 'تم الحذف من Firestore بنجاح' };
    } catch (err: any) {
      const msg = err?.message || 'تعذر الحذف من Firestore';
      FirebaseService.addLog('delete_book', 'failed', msg);
      return { success: false, message: msg };
    }
  },

  // Push Order/POS Sale to Firestore
  pushOrder: async (order: Order): Promise<{ success: boolean; message: string }> => {
    try {
      const orderRef = doc(db, 'orders', order.id);
      await setDoc(orderRef, {
        ...order,
        syncedToCloud: true,
        cloudProvider: 'firebase',
        updatedAt: new Date().toISOString()
      }, { merge: true });

      FirebaseService.addLog(
        'push_order',
        'success',
        `تمت مزامنة الطلبية/المبيعة #${order.id} (${order.orderType}) في Firestore`
      );
      return { success: true, message: 'تم حفظ الطلبية في Firestore' };
    } catch (err: any) {
      const msg = err?.message || 'تعذر حفظ الطلبية في Firestore';
      FirebaseService.addLog('push_order', 'failed', msg);
      return { success: false, message: msg };
    }
  },

  // Test connection to Firestore
  testConnection: async (): Promise<{ success: boolean; message: string; latencyMs: number }> => {
    const start = performance.now();
    try {
      const booksCol = collection(db, 'books');
      await getDocs(booksCol);
      const latencyMs = Math.round(performance.now() - start);

      FirebaseService.addLog(
        'test_connection',
        'success',
        `الاتصال بقاعدة بيانات Firestore السحابية شغال وموثق (زمن الاستجابة: ${latencyMs}ms)`
      );

      return {
        success: true,
        message: `الاتصال بـ Google Firestore متصل وفعال بنجاح (${latencyMs}ms)`,
        latencyMs
      };
    } catch (err: any) {
      const latencyMs = Math.round(performance.now() - start);
      const msg = err?.message || 'تعذر الاتصال بـ Google Firebase';
      FirebaseService.addLog('test_connection', 'failed', msg);
      return {
        success: false,
        message: `فشل الاتصال: ${msg}`,
        latencyMs
      };
    }
  }
};
