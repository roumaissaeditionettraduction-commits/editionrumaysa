// Compatibility wrapper redirecting legacy Sanity calls seamlessly to FirebaseService
import { FirebaseService, FirebaseSyncLog } from './firebaseService';
import { Book, Order, SanityConfig, SanitySyncLog } from '../types';
import { firebaseConfig } from './firebase';

export const SanityService = {
  // Config
  getConfig: (): SanityConfig => {
    return {
      projectId: firebaseConfig.projectId,
      dataset: 'production',
      apiVersion: '2024-01-01',
      apiToken: firebaseConfig.apiKey,
      useCdn: false,
      autoSyncOnSave: true,
      syncPosSales: true,
      isConnected: true,
      lastSyncTime: undefined,
      autoPullIntervalMinutes: 0
    };
  },

  saveConfig: (_config: SanityConfig): void => {
    // Config managed via Firebase env vars
  },

  // Logs
  getLogs: (): SanitySyncLog[] => {
    const fLogs = FirebaseService.getLogs();
    return fLogs.map(l => ({
      id: l.id,
      timestamp: l.timestamp,
      action: l.action as any,
      status: l.status,
      details: l.details,
      count: l.count
    }));
  },

  addLog: (
    action: SanitySyncLog['action'],
    status: SanitySyncLog['status'],
    details: string,
    count?: number
  ): void => {
    FirebaseService.addLog(action as any, status, details, count);
  },

  // Test connection to Firebase Firestore
  testConnection: async (_config?: any): Promise<{ success: boolean; message: string; latencyMs?: number }> => {
    return await FirebaseService.testConnection();
  },

  // Push single book to Firestore
  pushBook: async (book: Book, _config?: any): Promise<{ success: boolean; message: string }> => {
    return await FirebaseService.pushBook(book);
  },

  // Batch Push all books to Firestore
  batchPushBooks: async (
    books: Book[],
    _config?: any,
    onProgress?: (current: number, total: number) => void
  ): Promise<{ success: boolean; pushedCount: number; message: string }> => {
    if (onProgress) onProgress(books.length, books.length);
    return await FirebaseService.batchPushBooks(books);
  },

  // Delete book from Firestore
  deleteBook: async (bookId: string, _config?: any): Promise<{ success: boolean; message: string }> => {
    return await FirebaseService.deleteBook(bookId);
  },

  // Fetch all books from Firestore
  fetchBooks: async (_config?: any): Promise<{ success: boolean; books: Book[]; message: string }> => {
    return await FirebaseService.fetchAllBooks();
  },

  // Dynamic fetch for Bestseller Book [_type == "book" && isBestSeller == true][0]
  fetchBestsellerBook: async (): Promise<Book | null> => {
    try {
      const res = await FirebaseService.fetchAllBooks();
      if (res.success && res.books.length > 0) {
        return res.books.find(b => b.isBestSeller === true || b.isBestseller === true) || res.books[0];
      }
    } catch (e) {
      console.warn('Error fetching bestseller book', e);
    }
    return null;
  },

  // Push POS sale to Firestore
  pushPosSale: async (order: Order, _config?: any): Promise<{ success: boolean; message: string }> => {
    return await FirebaseService.pushOrder(order);
  },

  getSanitySchemas: () => {
    return {
      bookSchema: `// Sanity CMS Book Schema
export default {
  name: 'book',
  title: 'الكتب والإصدارات',
  type: 'document',
  fields: [
    {
      name: 'title',
      title: 'عنوان الكتاب',
      type: 'string',
      validation: Rule => Rule.required()
    },
    {
      name: 'author',
      title: 'المؤلف',
      type: 'string',
      validation: Rule => Rule.required()
    },
    {
      name: 'isBestSeller',
      title: 'عرض كـ الرواية الأكثر مبيعاً',
      type: 'boolean',
      initialValue: false,
      description: 'تحديد هذا الكتاب ليظهر في واجهة المتجر كـ الرواية الأكثر مبيعاً في الجزائر لعام 2026'
    },
    {
      name: 'pricePrint',
      title: 'سعر النسخة الورقية (دج)',
      type: 'number'
    },
    {
      name: 'priceEpub',
      title: 'سعر النسخة الرقمية ePub (دج)',
      type: 'number'
    },
    {
      name: 'summary',
      title: 'نبذة عن الرواية',
      type: 'text'
    },
    {
      name: 'coverImage',
      title: 'صورة الغلاف',
      type: 'image'
    }
  ]
}`,
      groqSnippet: `*[_type == "book" && isBestSeller == true][0]`,
      orderSchema: `// Firestore Order Document Structure
{
  "id": "ord-1",
  "customerName": "اسم الزبون",
  "totalAmount": 2400,
  "orderType": "pos",
  "items": []
}`
    };
  }
};

// Simulated Client for GROQ-like queries matching [_type == "book" && isBestSeller == true][0]
export const sanityClient = {
  fetch: async (queryStr: string): Promise<any> => {
    if (queryStr.includes('isBestSeller') || queryStr.includes('isBestseller')) {
      const res = await FirebaseService.fetchAllBooks();
      if (res.success && res.books.length > 0) {
        return res.books.find(b => b.isBestSeller === true || b.isBestseller === true) || res.books[0];
      }
    }
    const res = await FirebaseService.fetchAllBooks();
    return res.books;
  }
};

export const client = sanityClient;
