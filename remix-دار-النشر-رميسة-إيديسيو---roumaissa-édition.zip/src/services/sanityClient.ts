// Clean redirect from deprecated Sanity client to Firebase Firestore
import { db, firebaseApp, firebaseConfig } from './firebase';

export { db, firebaseApp, firebaseConfig };
export default db;
