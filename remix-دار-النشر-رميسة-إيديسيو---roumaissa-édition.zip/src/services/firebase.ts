import { initializeApp, getApps, getApp, type FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  onSnapshot,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  serverTimestamp,
  type Firestore,
  type Unsubscribe,
  type DocumentData,
  type QuerySnapshot
} from 'firebase/firestore';

export const firebaseConfig = {
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'maisoneditionrumaysa',
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyCUFqZlnWT1Cy5Ycq0OBJG1_TFpIBmirZQ',
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || 'maisoneditionrumaysa'}.firebaseapp.com`,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || 'maisoneditionrumaysa'}.appspot.com`,
};

// Safe initialization preventing duplicate instances
export const firebaseApp: FirebaseApp = getApps().length > 0 
  ? getApp() 
  : initializeApp(firebaseConfig);

export const db: Firestore = getFirestore(firebaseApp);

export {
  collection,
  doc,
  onSnapshot,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  serverTimestamp,
  type Unsubscribe,
  type DocumentData,
  type QuerySnapshot
};
