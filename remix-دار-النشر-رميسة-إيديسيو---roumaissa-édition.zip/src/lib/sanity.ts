// Clean redirect to Firebase
export * from '../services/firebase';
export { db as default } from '../services/firebase';
