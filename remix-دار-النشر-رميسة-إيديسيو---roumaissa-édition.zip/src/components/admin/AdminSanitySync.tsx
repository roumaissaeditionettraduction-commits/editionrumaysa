import React, { useState, useEffect } from 'react';
import {
  CloudLightning, Database, Check, AlertCircle, RefreshCw,
  UploadCloud, DownloadCloud, Key, ShieldCheck, Copy,
  CheckCircle, ArrowRight, ExternalLink, Terminal, Eye, EyeOff,
  Radio, Zap, Layers, Trash2
} from 'lucide-react';
import { Book, Order } from '../../types';
import { FirebaseService, FirebaseSyncLog } from '../../services/firebaseService';
import { StorageService } from '../../services/storage';
import { firebaseConfig } from '../../services/firebase';

interface AdminSanitySyncProps {
  books: Book[];
  orders: Order[];
  onRefreshAll: () => void;
}

export const AdminSanitySync: React.FC<AdminSanitySyncProps> = ({
  books,
  orders,
  onRefreshAll
}) => {
  const [logs, setLogs] = useState<FirebaseSyncLog[]>(FirebaseService.getLogs());
  const [showApiKey, setShowApiKey] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; latencyMs?: number } | null>(null);
  
  const [isBatchPushing, setIsBatchPushing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [copiedTab, setCopiedTab] = useState<string | null>(null);

  useEffect(() => {
    const handleLogUpdate = () => {
      setLogs(FirebaseService.getLogs());
    };
    window.addEventListener('roumaissa-firebase-logs-updated', handleLogUpdate);
    return () => window.removeEventListener('roumaissa-firebase-logs-updated', handleLogUpdate);
  }, []);

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    const res = await FirebaseService.testConnection();
    setTestResult(res);
    setIsTesting(false);
  };

  // Push all books to Firebase Firestore
  const handleBatchPushBooks = async () => {
    setIsBatchPushing(true);
    setActionMessage('جاري رفع ومزامنة جميع الكتب إلى Google Cloud Firestore...');
    
    const res = await FirebaseService.batchPushBooks(books);
    setIsBatchPushing(false);
    
    if (res.success) {
      setActionMessage(`نجحت العملية! تم رفع ومزامنة ${res.pushedCount} كتاب إلى Firestore بدون الحاجة لإعادة بناء المتجر.`);
    } else {
      setActionMessage(`فشلت المزامنة: ${res.message}`);
    }
    setTimeout(() => setActionMessage(null), 5000);
  };

  // Pull books from Firestore
  const handlePullBooks = async () => {
    setIsPulling(true);
    setActionMessage('جاري سحب الكتب من Google Cloud Firestore...');
    
    const res = await FirebaseService.fetchAllBooks();
    setIsPulling(false);
    
    if (res.success && res.books.length > 0) {
      StorageService.saveBooks(res.books);
      onRefreshAll();
      setActionMessage(`تم سحب وتحديث ${res.books.length} كتاب من Firestore بنجاح!`);
    } else if (res.success && res.books.length === 0) {
      setActionMessage('تم الاتصال بسحابة Firestore ولكن مجموعة books فارغة.');
    } else {
      setActionMessage(`تعذر سحب البيانات: ${res.message}`);
    }
    setTimeout(() => setActionMessage(null), 5000);
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(key);
    setTimeout(() => setCopiedTab(null), 2500);
  };

  const handleClearLogs = () => {
    localStorage.removeItem('roumaissa_firebase_logs_v1');
    setLogs([]);
  };

  const posOrdersCount = orders.filter(o => o.orderType === 'pos').length;

  const bookSchemaSnippet = `// 1. Sanity CMS Book Schema (مع حقل التميز isBestSeller):
export default {
  name: 'book',
  title: 'الكتب والإصدارات',
  type: 'document',
  fields: [
    { name: 'title', title: 'عنوان الكتاب', type: 'string' },
    { name: 'author', title: 'المؤلف', type: 'string' },
    {
      name: 'isBestSeller',
      title: 'عرض كـ الرواية الأكثر مبيعاً',
      type: 'boolean',
      initialValue: false,
      description: 'تحديد هذا الكتاب ليظهر في واجهة المتجر كـ الرواية الأكثر مبيعاً في الجزائر لعام 2026'
    },
    { name: 'pricePrint', title: 'سعر النسخة الورقية (دج)', type: 'number' },
    { name: 'priceEpub', title: 'سعر النسخة الرقمية (دج)', type: 'number' },
    { name: 'summary', title: 'نبذة عن الرواية', type: 'text' }
  ]
}

// 2. GROQ Query لجلب الرواية الأكثر مبيعاً ديناميكياً:
*[_type == "book" && isBestSeller == true][0]`;

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Automation Summary */}
      <div className="bg-stone-900 text-white p-6 rounded-2xl shadow-md border border-stone-800 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-80 h-80 bg-amber-600/10 rounded-full blur-3xl pointer-events-none -translate-x-1/2 -translate-y-1/2" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
                <Database className="w-5 h-5" />
              </span>
              <h2 className="text-xl font-bold font-editorial">الربط والمزامنة اللحظية مع Google Cloud Firestore</h2>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                مزامنة لحظية onSnapshot نشطة
              </span>
            </div>
            <p className="text-stone-300 text-xs leading-relaxed max-w-2xl">
              تم فك الارتباط بـ Sanity بالكامل. المتجر الآن مربوط مباشرة مع Google Cloud Firestore عبر مجموعة <strong>"books"</strong>.
              أي تحديث أو إضافة لكتاب ينعكس فوراً ولحظياً على الواجهة الحية في Vercel دون الحاجة لإعادة نشر التطبيق.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={handleTestConnection}
              disabled={isTesting}
              className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 rounded-xl text-xs font-bold flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin text-amber-400' : ''}`} />
              <span>{isTesting ? 'فحص الاتصال...' : 'اختبار الاتصال بـ Firebase'}</span>
            </button>
          </div>
        </div>

        {/* Test Result Alert */}
        {testResult && (
          <div className={`mt-4 p-3 rounded-xl border text-xs flex items-center justify-between gap-3 ${
            testResult.success
              ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-200'
              : 'bg-rose-950/40 border-rose-800/60 text-rose-200'
          }`}>
            <div className="flex items-center gap-2">
              {testResult.success ? (
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>{testResult.message}</span>
            </div>
            {testResult.latencyMs !== undefined && (
              <span className="font-mono text-[10px] bg-black/30 px-2 py-0.5 rounded text-stone-400">
                {testResult.latencyMs} ms
              </span>
            )}
          </div>
        )}

        {actionMessage && (
          <div className="mt-4 p-3 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-200 text-xs flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{actionMessage}</span>
          </div>
        )}
      </div>

      {/* Main Grid: Firebase Info & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Live Configuration View */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-5">
            <div className="flex items-center justify-between border-b border-stone-100 pb-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-stone-900 text-sm">بيانات الاعتماد السحابية (Vercel & Firebase)</h3>
              </div>
              <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                متصل عبر: Firebase Web SDK v13
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  معرف المشروع (Project ID)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={firebaseConfig.projectId}
                    className="w-full text-xs font-mono p-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-800 cursor-text select-text"
                  />
                  <button
                    onClick={() => handleCopy(firebaseConfig.projectId, 'pid')}
                    className="p-2.5 bg-stone-100 hover:bg-stone-200 rounded-xl text-stone-600 transition-colors"
                    title="نسخ المعرف"
                  >
                    {copiedTab === 'pid' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                <span className="text-[10px] text-stone-400 block mt-1">
                  مأخوذ تلقائياً من VITE_FIREBASE_PROJECT_ID
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  مفتاح الوصول (API Key)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type={showApiKey ? 'text' : 'password'}
                    readOnly
                    value={firebaseConfig.apiKey}
                    className="w-full text-xs font-mono p-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-800 cursor-text select-text"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="p-2.5 bg-stone-100 hover:bg-stone-200 rounded-xl text-stone-600"
                    title={showApiKey ? 'إخفاء المفتاح' : 'إظهار المفتاح'}
                  >
                    {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => handleCopy(firebaseConfig.apiKey, 'key')}
                    className="p-2.5 bg-stone-100 hover:bg-stone-200 rounded-xl text-stone-600 transition-colors"
                    title="نسخ المفتاح"
                  >
                    {copiedTab === 'key' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                <span className="text-[10px] text-stone-400 block mt-1">
                  مأخوذ تلقائياً من VITE_FIREBASE_API_KEY
                </span>
              </div>
            </div>

            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-950 space-y-2">
              <div className="flex items-center gap-2 font-bold text-emerald-800">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>المزامنة الحية مفعلة بالكامل (Real-time Firestore)</span>
              </div>
              <p className="text-[11px] leading-relaxed text-emerald-900/80">
                يقوم التطبيق بالاستماع الدائم عبر <code>onSnapshot</code> لمجموعة <strong>books</strong> في Firestore. عند إضافة أو تعديل أي كتاب في قاعدة البيانات، يتم تحديث الواجهة تلقائياً لجميع الزوار وفي المتجر ونظام نقاط البيع POS لحظة بلحظة.
              </p>
            </div>
          </div>

          {/* Sync Operations: Batch Push & Pull */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <h3 className="font-bold text-stone-900 text-sm">عمليات المزامنة اليدوية والحزم (Batch Sync)</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border border-stone-200 bg-stone-50/70 space-y-3">
                <div className="flex items-center gap-2 font-bold text-xs text-stone-800">
                  <UploadCloud className="w-4 h-4 text-amber-600" />
                  <span>رفع جميع الكتب إلى Firestore</span>
                </div>
                <p className="text-[11px] text-stone-500 leading-relaxed">
                  رفع كافة الكتب الحالية ({books.length} كتاب) إلى مجموعة <code>books</code> في Google Firestore دفعة واحدة.
                </p>
                <button
                  onClick={handleBatchPushBooks}
                  disabled={isBatchPushing}
                  className="w-full py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors disabled:opacity-50"
                >
                  <UploadCloud className={`w-3.5 h-3.5 text-amber-400 ${isBatchPushing ? 'animate-bounce' : ''}`} />
                  <span>{isBatchPushing ? 'جاري الرفع سحابياً...' : `رفع وحفظ ${books.length} كتاب في Firestore`}</span>
                </button>
              </div>

              <div className="p-4 rounded-xl border border-stone-200 bg-stone-50/70 space-y-3">
                <div className="flex items-center gap-2 font-bold text-xs text-stone-800">
                  <DownloadCloud className="w-4 h-4 text-emerald-600" />
                  <span>سحب الكتب من Firestore فوراً</span>
                </div>
                <p className="text-[11px] text-stone-500 leading-relaxed">
                  تحديث فوري لقائمة الكتب عبر سحب جميع المستندات المخزنة سحابياً في Google Firestore.
                </p>
                <button
                  onClick={handlePullBooks}
                  disabled={isPulling}
                  className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors disabled:opacity-50"
                >
                  <DownloadCloud className={`w-3.5 h-3.5 text-emerald-200 ${isPulling ? 'animate-bounce' : ''}`} />
                  <span>{isPulling ? 'جاري السحب سحابياً...' : 'سحب وتحديث الكتب من Firestore'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Firestore Schema Reference */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-600" />
                <span>هيكل بيانات مستندات Firestore (Schema)</span>
              </h3>
              <button
                onClick={() => handleCopy(bookSchemaSnippet, 'schema')}
                className="text-xs text-amber-800 hover:text-amber-900 font-bold flex items-center gap-1"
              >
                {copiedTab === 'schema' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>نسخ الهيكل</span>
              </button>
            </div>
            <pre className="p-4 bg-stone-900 text-stone-200 rounded-xl text-[11px] font-mono overflow-x-auto max-h-48 text-left dir-ltr">
              {bookSchemaSnippet}
            </pre>
          </div>

        </div>

        {/* Right 1 Col: Live Activity Logs */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-amber-600" />
                <h3 className="font-bold text-stone-900 text-sm">سجل المزامنة السحابية</h3>
              </div>
              {logs.length > 0 && (
                <button
                  onClick={handleClearLogs}
                  className="text-[11px] text-stone-400 hover:text-rose-600 flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>مسح السجل</span>
                </button>
              )}
            </div>

            <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
              {logs.length === 0 ? (
                <div className="text-center py-10 text-stone-400 space-y-2">
                  <Database className="w-8 h-8 mx-auto stroke-1 opacity-50" />
                  <p className="text-xs">لا توجد عمليات مسجلة حتى الآن.</p>
                </div>
              ) : (
                logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl border border-stone-100 bg-stone-50/70 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="font-mono text-stone-400">{log.timestamp}</span>
                      <span className={`px-2 py-0.5 rounded-full font-bold ${
                        log.status === 'success'
                          ? 'bg-emerald-100 text-emerald-800'
                          : log.status === 'failed'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {log.status === 'success' ? 'ناجح' : log.status === 'failed' ? 'فشل' : 'قيد المعالجة'}
                      </span>
                    </div>
                    <p className="text-stone-700 text-[11px] font-medium leading-relaxed">
                      {log.details}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
